largura = window.screen.width;
altura = window.screen.height;

larguraMatrix = 10
alturaMatrix = 13

var k = 0;
var qtdMinas = 10;
var campo = [];
//var r=130;

document.getElementById("game").style.width = "500px";
document.getElementById("game").style.height = "500px";
document.getElementById("game").style.backgroundColor = "black";
document.getElementById("game").style.marginLeft = (largura/2 - 500/2) + "px";
document.getElementById("game").style.marginTop = ((altura-200)/2 - 500/2) + "px";

larguraGame = 500;
alturaGame = 500;

document.getElementById("buttonStart").style.position = "relative";
document.getElementById("buttonStart").style.left = larguraGame/2 + "px";
document.getElementById("buttonStart").style.top = alturaGame/2 + "px";

function start(){

    

    document.getElementById("buttonStart").style.display = "none";

    gerarCampo()
    console.log(campo)
    

    document.getElementById("campo").style.position = "relative";
    document.getElementById("campo").style.width = "160px";
    document.getElementById("campo").style.height = "208px";
    document.getElementById("campo").style.left = (500/2 - 160/2) + "px";
    document.getElementById("campo").style.top = ((500-200)/2 - 160/2) + "px";
    
    for(i=1; i<=larguraMatrix; i++){
        for(j=1; j<=alturaMatrix;j++){
            k++;
            document.getElementById("campo").innerHTML += "<img onclick='updateCampo("+k+")' id='"+k+"' src='Sprites/default.png' alt='' style='float:left;'>";
        }
    }

}

function gerarCampo(){

    for(i=0; i<=larguraMatrix*alturaMatrix; i++){
        campo.push(0);
    }
    for(i=1; i<=qtdMinas; i++){
        r = Math.floor(Math.random() * 130)
        while (campo[r] == 10) {
            r = Math.floor(Math.random() * 130)
        }
        
        campo[r] = 10;

        if(r>larguraMatrix && r<((larguraMatrix*alturaMatrix)-larguraMatrix) && ((r-1)%10) != 0 && r%10 != 0) {
            pos1 = r-larguraMatrix-1
            pos2 = r-larguraMatrix
            pos3 = r-larguraMatrix+1
            pos4 = r-1
            pos5 = r+1
            pos6 = r+larguraMatrix-1
            pos7 = r+larguraMatrix
            pos8 = r+larguraMatrix+1


            if(campo[pos1] != 10){
                campo[pos1] += 1
            }
            if(campo[pos2] != 10){
                campo[pos2] += 1
            }
            if(campo[pos3] != 10){
                campo[pos3] += 1
            }
            if(campo[pos4] != 10){
                campo[pos4] += 1
            }
            if(campo[pos5] != 10){
                campo[pos5] += 1
            }
            if(campo[pos6] != 10){
                campo[pos6] += 1
            }
            if(campo[pos7] != 10){
                campo[pos7] += 1
            }
            if(campo[pos8] != 10){
                campo[pos8] += 1
            }


            
        } else if (((r-1)%10) == 0) {

            pos2 = r-larguraMatrix
            pos3 = r-larguraMatrix+1
            pos5 = r+1
            pos7 = r+larguraMatrix
            pos8 = r+larguraMatrix+1


            
            if(campo[pos2] != 10){
                campo[pos2] += 1
            }
            if(campo[pos3] != 10){
                campo[pos3] += 1
            }
            
            if(campo[pos5] != 10){
                campo[pos5] += 1
            }
            
            if(campo[pos7] != 10){
                campo[pos7] += 1
            }
            if(campo[pos8] != 10){
                campo[pos8] += 1
            }



        } else if (r%10 == 0){
            pos1 = r-larguraMatrix-1
            pos2 = r-larguraMatrix
            pos4 = r-1
            pos6 = r+larguraMatrix-1
            pos7 = r+larguraMatrix


            if(campo[pos1] != 10){
                campo[pos1] += 1
            }
            if(campo[pos2] != 10){
                campo[pos2] += 1
            }
            
            if(campo[pos4] != 10){
                campo[pos4] += 1
            }
            
            if(campo[pos6] != 10){
                campo[pos6] += 1
            }
            if(campo[pos7] != 10){
                campo[pos7] += 1
            }
            
            //r += 2

            console.log(r)

    } else if (r<=larguraMatrix){

        if(r==1){
            pos5 = r+1
            pos7 = r+larguraMatrix
            pos8 = r+larguraMatrix+1

            
            if(campo[pos5] != 10){
                campo[pos5] += 1
            }
            if(campo[pos7] != 10){
                campo[pos7] += 1
            }
            if(campo[pos8] != 10){
                campo[pos8] += 1
            }

        } else if (r == larguraMatrix){
            pos4 = r-1
            pos6 = r+larguraMatrix-1
            pos7 = r+larguraMatrix

            if(campo[pos4] != 10){
                campo[pos4] += 1
            }
            if(campo[pos6] != 10){
                campo[pos6] += 1
            }
            if(campo[pos7] != 10){
                campo[pos7] += 1
            }
        } else {
            pos4 = r-1
            pos5 = r+1
            pos6 = r+larguraMatrix-1
            pos7 = r+larguraMatrix
            pos8 = r+larguraMatrix+1

            if(campo[pos4] != 10){
                campo[pos4] += 1
            }
            if(campo[pos5] != 10){
                campo[pos5] += 1
            }
            if(campo[pos6] != 10){
                campo[pos6] += 1
            }
            if(campo[pos7] != 10){
                campo[pos7] += 1
            }
            if(campo[pos8] != 10){
                campo[pos8] += 1
            }
        }

            
            

    } else if (r>=((larguraMatrix*alturaMatrix)-larguraMatrix)){

            if(r == (larguraMatrix*alturaMatrix)-larguraMatrix + 1){
                pos2 = r-larguraMatrix
                pos3 = r-larguraMatrix+1
                pos5 = r+1
            


               
                if(campo[pos2] != 10){
                    campo[pos2] += 1
                }
                if(campo[pos3] != 10){
                    campo[pos3] += 1
                }
                
                if(campo[pos5] != 10){
                    campo[pos5] += 1
                }

            } else if (r == (larguraMatrix*alturaMatrix)){
                pos1 = r-larguraMatrix-1
                pos2 = r-larguraMatrix
                pos4 = r-1
            


                if(campo[pos1] != 10){
                    campo[pos1] += 1
                }
                if(campo[pos2] != 10){
                    campo[pos2] += 1
                }
                
                if(campo[pos4] != 10){
                    campo[pos4] += 1
                }
                
            } else {
                pos1 = r-larguraMatrix-1
                pos2 = r-larguraMatrix
                pos3 = r-larguraMatrix+1
                pos4 = r-1
                pos5 = r+1
            


                if(campo[pos1] != 10){
                    campo[pos1] += 1
                }
                if(campo[pos2] != 10){
                    campo[pos2] += 1
                }
                if(campo[pos3] != 10){
                    campo[pos3] += 1
                }
                if(campo[pos4] != 10){
                    campo[pos4] += 1
                }
                if(campo[pos5] != 10){
                    campo[pos5] += 1
                }
            }

            
            

    }

    }

}

function updateCampo(k){
    if(campo[k]==0){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty0.png"
    } else if (campo[k]==1){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty1.png"
    }else if (campo[k]==2){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty2.png"
    }else if (campo[k]==3){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty3.png"
    }else if (campo[k]==4){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty4.png"
    }else if (campo[k]==5){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty5.png"
    }else if (campo[k]==6){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty6.png"
    }else if (campo[k]==7){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty7.png"
    }else if (campo[k]==8){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty8.png"
    }else if (campo[k]==10){
        document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/mine.png"

        //document.getElementById("game").innerHTML = "<p>GAME OVER</p>"

    }
    
    console.log("Update")
    console.log(k, campo[k])
    
}


function mostrarMinas(){

    for(k=1; k<=larguraMatrix*alturaMatrix; k++){
        if(campo[k]==0){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty0.png"
        } else if (campo[k]==1){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty1.png"
        }else if (campo[k]==2){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty2.png"
        }else if (campo[k]==3){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty3.png"
        }else if (campo[k]==4){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty4.png"
        }else if (campo[k]==5){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty5.png"
        }else if (campo[k]==6){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty6.png"
        }else if (campo[k]==7){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty7.png"
        }else if (campo[k]==8){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/empty8.png"
        }else if (campo[k]==10){
            document.getElementById(k).attributes.getNamedItem("src").value = "Sprites/mine.png"
        }
    }

    

}